# v135 final theorem-ready adjudication and claim-freeze plan

v134 still has kernel blockers. v135 should not be run as final adjudication until these are closed; use a focused kernel refinement first if needed.

## Remaining blocker actions

- `K-FINAL-LOWER-BOUND-KERNEL-NOT-CLOSED`: Close K-A with explicit witness polygon certificates, K-B with event-aware geometry certificates, or K-C with a reviewed support-to-area final lemma.
- `K-ROUNDING-GUARD-NOT-OPERATION-LEVEL-FINAL`: Close one final kernel route, then rerun the rounding ledger so every operation row is proof-grade.
- `K-PATCH-FINAL-KERNEL-REPLAY-BLOCKED`: Close a proof-grade kernel route and finalize operation-level rounding, then rerun all 16 patch records through that route.

## Final package policy

Use v135 only after proof-grade kernel, row-level evidence, global replay, patch final replay, and proof obligations have all passed.
