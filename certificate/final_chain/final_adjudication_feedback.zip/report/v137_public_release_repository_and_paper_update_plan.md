# v137 public release, repository, and paper update plan

v136 has frozen the final theorem-ready certificate package within this scope:

```text
Brass--Sharifi three-test-family / 0.83201 lower-bound certificate scope
```

v137 should prepare public-facing materials only after preserving the v136 claim boundary verbatim:

1. Update README and README.zh-CN.
2. Update CERTIFICATE / ARTIFACTS / EXPECTED_OUTPUTS materials.
3. Draft paper update sections that cite the v136 final adjudication package.
4. Preserve these explicit false flags:
   - independent_external_verification_completed = false
   - proof_assistant_formalization_completed = false
   - nonconvex_lower_bound_claimed = false
   - branch_a_closed = false
