# v133 minimal missing evidence upload list

No missing row-source blockers remain in this v133 run.

If these blockers remain on the local full artifact root, upload the raw ledger/replay output directories that were produced during the original BS0832/v109 runs but were not included in the feedback/project zips.
